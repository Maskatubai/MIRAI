package http

import (
	"cnc/core/config"
	"fmt"
	"log"
	"net/http"
	"path/filepath"
)

func Serve() {
	staticDir := "assets/static"

	http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		if len(r.URL.Path) < 2 {
			http.ServeFile(w, r, filepath.Join(staticDir, "index.html"))
			return
		}

		log.Printf("[http] %s requested %s\r\n", r.RemoteAddr, r.URL.Path)
		http.ServeFile(w, r, filepath.Join(staticDir, r.URL.Path))
	})

	log.Printf("[http] Server listening on port %d\n", config.Config.WebServer.Http)
	log.Fatal(http.ListenAndServe(fmt.Sprintf(":%d", config.Config.WebServer.Http), nil))
}

func Serve2() {
	log.Printf("[http] Server listening on port %d\n", config.Config.WebServer.Http2)
	log.Fatal(http.ListenAndServe(fmt.Sprintf(":%d", config.Config.WebServer.Http2), nil))
}
