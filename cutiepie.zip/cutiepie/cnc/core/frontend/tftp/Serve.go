package tftp

import (
	"cnc/core/config"
	"errors"
	"fmt"
	"github.com/pin/tftp"
	"io"
	"log"
	"os"
	"path/filepath"
)

var (
	staticDir = "assets/static/"
)

func Serve() {
	server := tftp.NewServer(func(filename string, rf io.ReaderFrom) error {
		raddr := rf.(tftp.OutgoingTransfer).RemoteAddr()

		file, err := os.Open(filepath.Join(staticDir, filename))
		if err != nil {
			return errors.New("file not found")
		}

		defer file.Close()

		_, err = rf.ReadFrom(file)
		if err != nil {
			return err
		}

		log.Printf("[tftp] %s requested %s\n", raddr.IP.String(), filename)

		return nil
	}, nil)

	log.Printf("[tftp] Server listening on port %d\n", config.Config.WebServer.Ftp)
	err := server.ListenAndServe(fmt.Sprintf(":%d", config.Config.WebServer.Ftp))
	if err != nil {
		return
	}
}
