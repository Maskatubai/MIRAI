package masters

import "fmt"

func (a *Admin) ReadLine(prompt string, masked bool) (string, error) {
	buf := make([]byte, 2048)
	pos := 0

	if len(prompt) >= 1 {
		a.Printf(prompt)
	}

	for {
		if len(buf) < pos+2 {
			fmt.Println("BUFF LEN:", len(buf))
			fmt.Println("Prevented Buffer Overflow.", a.conn.RemoteAddr())
			return string(buf), nil
		}

		n, err := a.conn.Read(buf[pos : pos+1])
		if err != nil || n != 1 {
			return "", err
		}
		switch buf[pos] {
		case 0xFF:
			n, err := a.conn.Read(buf[pos : pos+2])
			if err != nil || n != 2 {
				return "", err
			}
			pos--
		case 0x7F, 0x08:
			if pos > 0 {
				a.Printf("\b \b")
				pos--
			}
			pos--
		case 0x0D, 0x09:
			pos--
		case 0x0A, 0x00:
			a.Printf("\r\n")
			return string(buf[:pos]), nil
		case 0x03:
			a.Printf("^C\r\n")
			return "", nil
		default:
			if buf[pos] == 0x1B {
				buf[pos] = '^'
				a.Printf(string(buf[pos]))
				pos++
				buf[pos] = '['
				a.Printf(string(buf[pos]))
			} else if masked {
				a.Printf("*")
			} else {
				a.Printf(string(buf[pos]))
			}
		}
		pos++
	}
}
