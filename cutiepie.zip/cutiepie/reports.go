package main

import (
	"fmt"
	"net"
	"time"
)

func main() {
	r, e := net.Listen("tcp", "0.0.0.0:7733")
	if e != nil {
		return
	}
	defer r.Close()

	for {
		c, e := r.Accept()
		if e != nil {
			fmt.Println(e)
			continue
		}
		go func() {
			defer c.Close()
			b := make([]byte, 1024)
			for {
				n, e := c.Read(b)
				if e != nil {
					time.Sleep(300 * time.Millisecond)
					continue
				}
				fmt.Printf("\033[44m(%s)\033[0m %s", time.Now().Format("2006-01-02 03:04 PM"), string(b[:n]))
			}
		}()
	}
}
